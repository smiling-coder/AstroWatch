"""ASTROWATCH AI backend: Skyfield-based trajectories + grounded AI assistant.
Run:  uvicorn main:app --reload
"""
import math
import os
import time
from datetime import datetime, timezone

import httpx
import numpy as np
from fastapi import FastAPI, HTTPException, Query, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from skyfield.api import load

app = FastAPI(title="ASTROWATCH AI backend")
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "http://127.0.0.1:5500,http://localhost:5500,null").split(","),
    allow_methods=["*"],
    allow_headers=["*"],
)

SBDB = "https://ssd-api.jpl.nasa.gov/sbdb.api"
ts = load.timescale()
_eph = None
OBL = math.radians(23.4392911)  # obliquity of the ecliptic, J2000


def eph():
    """Load the JPL DE421 ephemeris (downloaded once, about 17 MB)."""
    global _eph
    if _eph is None:
        _eph = load("de421.bsp")
    return _eph


def solve_kepler(M, e):
    E = np.where(e < 0.8, M, math.pi)
    for _ in range(30):
        E = E - (E - e * np.sin(E) - M) / (1 - e * np.cos(E))
    return E


def propagate(el, jd):
    """Two-body heliocentric position (AU, ecliptic J2000) at Julian dates jd."""
    a, e = el["a"], el["e"]
    n = 0.9856076686 / a**1.5  # mean motion in degrees/day (Gaussian constant)
    M = np.radians((el["ma"] + n * (jd - el["epoch"])) % 360.0)
    E = solve_kepler(M, e)
    x = a * (np.cos(E) - e)
    y = a * math.sqrt(1 - e * e) * np.sin(E)
    i, om, w = (math.radians(el[k]) for k in ("i", "om", "w"))
    cw, sw, co, so, ci, si = (math.cos(w), math.sin(w), math.cos(om), math.sin(om),
                              math.cos(i), math.sin(i))
    X = (cw * co - sw * so * ci) * x + (-sw * co - cw * so * ci) * y
    Y = (cw * so + sw * co * ci) * x + (-sw * so + cw * co * ci) * y
    Z = (sw * si) * x + (cw * si) * y
    return np.stack([X, Y, Z], axis=-1)


async def sbdb_elements(des: str):
    async with httpx.AsyncClient(timeout=20) as c:
        r = await c.get(SBDB, params={"sstr": des})
    j = r.json()
    if "orbit" not in j:
        raise HTTPException(404, "Object not found in JPL Small-Body Database")
    els = {x["name"]: x for x in j["orbit"]["elements"]}
    keys = ("a", "e", "i", "om", "w", "ma")
    try:
        el = {k: float(els[k]["value"]) for k in keys}
        el["epoch"] = float(j["orbit"]["epoch"])
    except (KeyError, TypeError, ValueError):
        raise HTTPException(422, "Orbital elements incomplete for this object")
    if not 0 <= el["e"] < 0.99 or el["a"] <= 0:
        raise HTTPException(422, "Only bound elliptical orbits are supported")
    sig = {k: float(els[k]["sigma"]) for k in keys if els[k].get("sigma")}
    return el, sig


@app.get("/api/trajectory")
async def trajectory(
    des: str,
    days: int = Query(730, ge=30, le=3650),
    step: int = Query(10, ge=1, le=60),
    samples: int = Query(40, ge=0, le=200),
):
    el, sig = await sbdb_elements(des)
    now = datetime.now(timezone.utc)
    offs = np.arange(-days, days + 1, step)
    t = ts.utc(now.year, now.month, now.day + offs)
    jd = t.tdb

    # Earth relative to the Sun from Skyfield / DE421, rotated to the ecliptic.
    X, Y, Z = (eph()["earth"] - eph()["sun"]).at(t).position.au
    earth = np.stack([X, Y * math.cos(OBL) + Z * math.sin(OBL),
                      -Y * math.sin(OBL) + Z * math.cos(OBL)], axis=-1)
    obj = propagate(el, jd)
    dist = np.linalg.norm(obj - earth, axis=1)

    # Monte Carlo over published element sigmas (covariance ignored).
    spread = np.zeros(len(offs))
    if samples and sig:
        rng = np.random.default_rng(1)
        acc = np.zeros(len(offs))
        for _ in range(samples):
            s = {k: el[k] + rng.normal(0, sig.get(k, 0)) for k in ("a", "e", "i", "om", "w", "ma")}
            s["e"] = min(max(s["e"], 0.0), 0.98)
            s["epoch"] = el["epoch"]
            acc += np.sum((propagate(s, jd) - obj) ** 2, axis=1)
        spread = np.sqrt(acc / samples)

    pts = [
        {"t": int(o), "obj": np.round(p, 5).tolist(), "earth": np.round(q, 5).tolist(),
         "dist": round(float(d), 6), "sigma": round(float(sg), 6)}
        for o, p, q, d, sg in zip(offs, obj, earth, dist, spread)
    ]
    return {
        "des": des, "days": days, "step": step, "epoch_jd": el["epoch"],
        "method": ("Two-body Kepler propagation from JPL SBDB elements; Earth from Skyfield "
                   "(JPL DE421). Planetary perturbations are ignored. Violet cloud = Monte Carlo "
                   "over published element sigmas (covariance ignored), not an official uncertainty."),
        "points": pts,
    }


class Chat(BaseModel):
    question: str
    lang: str = "en"
    object: dict | None = None


SYSTEM = (
    "You are ASTROWATCH INTELLIGENCE, an educational assistant about near-Earth objects. "
    "Use ONLY the object data provided in the user message for numbers. If a value is null or "
    "missing, say it is not available; never estimate or invent measurements, impact probabilities "
    "or collision warnings. A close approach is not an impact. Say you cannot verify calculations "
    "independently. Keep answers under 150 words. Answer in Kannada if lang is 'kn', otherwise English."
)


_hits = {}


def too_many(ip):
    """Allow at most 10 AI questions per minute per visitor."""
    now = time.time()
    h = [t for t in _hits.get(ip, []) if now - t < 60] + [now]
    _hits[ip] = h
    return len(h) > 10


@app.post("/api/chat")
async def chat(b: Chat, request: Request):
    if too_many(request.client.host if request.client else "?"):
        raise HTTPException(429, "Too many questions, wait a minute")
    key = os.getenv("ANTHROPIC_API_KEY")
    if not key:
        raise HTTPException(503, "ANTHROPIC_API_KEY is not set")
    import anthropic

    client = anthropic.AsyncAnthropic(api_key=key)
    msg = await client.messages.create(
        model=os.getenv("ASTRO_MODEL", "claude-sonnet-5-5"),
        max_tokens=600,
        system=SYSTEM,
        messages=[{"role": "user", "content":
                   f"lang={b.lang}\nSelected object data (null = none): {b.object}\n"
                   f"Question: {b.question[:500]}"}],
    )
    return {"answer": "".join(x.text for x in msg.content if x.type == "text")}


@app.get("/api/health")
def health():
    return {"ok": True, "ai": bool(os.getenv("ANTHROPIC_API_KEY"))}
