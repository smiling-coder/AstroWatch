# ASTROWATCH AI

```
astrowatch/
├── index.html  style.css  script.js      ← website (GitHub Pages)
└── backend/    main.py  requirements.txt ← FastAPI + Skyfield + AI
```

## Run the backend (Windows, VS Code terminal)

```
cd backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
set ANTHROPIC_API_KEY=your-key-here
uvicorn main:app --reload
```

- Skip the API key to use the website's built-in rule-based assistant.
- First trajectory request downloads `de421.bsp` (about 17 MB), so you need internet.
- Check it works: open http://localhost:8000/api/health

## Run the website

Open `index.html` (or use VS Code Live Server). It talks to `http://localhost:8000`.
To use a deployed backend, add this line in `index.html` before `script.js`:
`<script>window.ASTRO_API="https://your-backend.example.com"</script>`
and set `ALLOWED_ORIGINS` on the server to your site's address (default allows only local Live Server on port 5500 and file:// pages). AI questions are limited to 10 per minute per visitor.

## Endpoints

- `GET /api/trajectory?des=99942 Apophis&days=730&step=10` — Earth and object positions (AU, ecliptic) and Earth distance
- `POST /api/chat` — assistant grounded in the selected object's data
- `GET /api/health`

## Honest limits

Orbits use two-body propagation from JPL elements, so planetary perturbations are ignored. The uncertainty cloud samples published element sigmas and ignores covariance. Neither is an official JPL prediction. Never put your API key in the website files.
